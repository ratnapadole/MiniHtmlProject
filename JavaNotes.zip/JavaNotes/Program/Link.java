
import java.util.*;

public class Link{
public static void main(String args[]){
LinkedList<String>  obj =new  LinkedList<String>();
  
 // LinkedList<String>  obj =new  <String> LinkedList();  
 
//obj.add(34);
obj.add("ABC");

System.out.println("size = "+obj.size());

System.out.println("77");


System.out.println(obj);


// [12,86,"tt"]

}




}
