
class A{
int c=34;
}

class B extends A{


}
class C extends B{

}


class D extends C{


public static void main(String args[]){

D obj=new D();
System.out.println("char value is= "+obj.c);
//System.out.println("char value is= "+v);
}



}

